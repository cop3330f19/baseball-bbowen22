/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseball;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.xml.bind.JAXB;


/**
 *
 * @author Bri
 */
public class BaseballController implements Initializable {
    
    @FXML private ListView teamList;
    @FXML private TableView battingAverageTable;
    @FXML private TableColumn <String, BaseballData> colPlayer;
    @FXML private TableColumn <String, BaseballData> colBattingAvg;
    
    //ArrayList of BaseballData objects
    private List<BaseballData> playerInfo = new ArrayList<>();
    
    //ArrayList of the top players 
    private List<String> topPlayers = new ArrayList<>();
    
    //Gets the directory path of the project
    private final String DIR = System.getProperty("user.dir");
          
    /**
     * Called to initialize a controller after its root element has been
     * completely processed.
     *
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        //Read baseball info from xml file, sets playerInfo list
        readFile();
        
        //ChangeListerner for when you click on a ListView Item
        teamList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
               
                //Find the team chosen in the ArrayList
                //int idx = findTeam(newValue);
                
                //Link the column's cell value to the get function of the BaseballData Class.
                //REMEMBER the name in the quotation marks should match the case of the get function
                colPlayer.setCellValueFactory(new PropertyValueFactory<>("Name"));
                colBattingAvg.setCellValueFactory(new PropertyValueFactory<>("Avg"));

                //Create an ObservableList object to store the BaseballData object(s)
                ObservableList<BaseballData> result = FXCollections.observableArrayList();
                
                //Add the BaseballData object to the list
                for (int i = 0; i < playerInfo.size(); i++) {
                   String team = playerInfo.get(i).getTeam();
                   if(findTeamAvg(team) < playerInfo.get(i).getAvg()){
                       result.add(playerInfo.get(i));
                   }
               }
              
                //Bind the list  to the table
                battingAverageTable.setItems(result);
                
            }
        });
    }
    
    /**
     * Sequential search of the states by name
     * @param value
     * @return 
     */
    
    //private int findTeam(String value){
    // 
     //   for(int i = 0; i < playerInfo.size(); i++)
      //      if(playerInfo.get(i).getTeam().equals(value))
       //         return i;
        //return 0;
    //}
    
    //Find the total team average
    private double findTeamAvg (String team) {
        
        int count = 0;
        double total = 0;
        double teamAvg = 0;
        for(int i = 0; i < playerInfo.size(); i++) {
            if(playerInfo.get(i).getTeam().equals(team)) {
                total += playerInfo.get(i).getAvg();
                count ++;
            }
        }
        teamAvg = total/count;
        return teamAvg;
    }
    
    /**
     * Read file contents and populate the Lists and ListView
     */
    private void readFile() {
        
        //ObservableList to add teams to the ListView
        ObservableList<String> List = FXCollections.observableArrayList();
        
        //Open xml file for input
        try(BufferedReader input = 
                Files.newBufferedReader(Paths.get("/Users/Bri/NetBeansProjects/BaseballProg/src/Data/baseball.xml"))){
            
               MLB playersFromFile = JAXB.unmarshal(input, MLB.class);
               playerInfo = playersFromFile.getPlayers();
               
               for (int i = 0; i < playerInfo.size(); i++) {
                   if(!List.contains(playerInfo.get(i).getTeam()))
                   List.add(playerInfo.get(i).getTeam());
               }
            
        
        }catch(IOException ioException){
            System.err.println("Error openning file");
            //e.printStackTrace();
        }
        
        //Sorts the List of BaseballData objects by team name in ascending order
        Collections.sort(playerInfo, new TeamsComparator());
        
        //Sorts the ObservableList
        Collections.sort(List);
        
        //Binds the ObservableList to the ListView
        teamList.setItems(List);
    }
}
    

     
    
         


