/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseball;

/**
 *
 * This class stores the data read from the file
 * 
 * @author Bri
 */

public class BaseballData {
    private String name;
    private String team;
    private int atBats;
    private int hits;
    private double avg;
    
    public BaseballData () {
        this.name = "";
        this.team = "";
        this.atBats = 0;
        this.hits = 0;
        this.avg = 0;
    }
    
    public BaseballData (String name, String team, int atBats, int hits) {
        this.name = name;
        this.team = team;
        this.atBats = atBats;
        this.hits = hits;
        this.avg = (hits/atBats);  
    }    
    
    public String getName () {
        return name;
    }
    
    public void setName (String name) {
        this.name = name;
    }
    
    public String getTeam () {
        return team;
    }
    
    public void setTeam (String team) {
        this.team = team;
    }
    
    public int getAtBats () {
        return atBats;
    }
    
    public void setAtBats (int atBats) {
        this.atBats = atBats;
    }
    
    public int getHits () {
        return hits;
    }
    
    public void setHits (int hits) {
        this.hits = hits;
    }
    
    public double getAvg () {
        return avg;
    }
    
    public void setAvg (int atBats, int hits) {
        this.avg = (hits/atBats);
    }
}
